<!DOCTYPE html>
<html>
<head>
    <title>Pendaftaran Berhasil</title>
</head>
<body>
    <h2>Pendaftaran Berhasil</h2>
    <p>Selamat, Anda telah berhasil mendaftar!</p>

    <form action="logout?action=logout" method="POST">
            <button type="submit" class="register-button">logout</button>
        </form>
</body>
</html>
s