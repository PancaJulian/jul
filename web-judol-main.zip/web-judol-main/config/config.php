<?php
define('BASEURL', '/web-judol/');
# Digunakan untuk menentukan base url menyesuaikan direktori